Mike Ogrysko
Data Structures 605.202
Lab 2 - AdjMatrix

java version "1.8.0_121"
Java(TM) SE Runtime Environment (build 1.8.0_121-b13)
Java HotSpot(TM) 64-Bit Server VM (build 25.121-b13, mixed mode)

Developed files in Atom 1.49.0
Debugged in Eclipse Photon Release (4.8.0)

To compile and run the program:
Unzip package ensuring that all files appear in the same directory
In terminal, type javac AdjMatrix.java
Ensure that all inputs are placed in the project
To run, type java AdjMatrix "PathsGraphInput.txt" "PathsGraphOutput.txt"
Specified output files will be placed in the project directory
Output will display on screen and will print to the specified file
